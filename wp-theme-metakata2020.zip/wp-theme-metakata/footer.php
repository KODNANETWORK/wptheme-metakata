<?php
/**
 * The template for displaying the footer
 * Contains the footer element
 * @link https://kodna.net/
 * @package WordPress
 * @subpackage MetaKata
 * @since 0
 */
?>
<!-- footer -->
<footer class="site_footer">
<p class="copyright"> © Copyright. All rights reserved.</p>
</footer>
<?php wp_footer(); ?>
</body>
</html>
